import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';

class Tela1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(child: Text('Historia')),
        backgroundColor: const Color.fromARGB(255, 11, 206, 5),
      ),
      body: const Center(
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 50),
              child: Text(
                'Em Frogger, não há uma narrativa complexa como em muitos jogos contemporâneos. Em vez disso, a história é bastante simples e direta. O jogo coloca os jogadores no controle de uma rã que precisa atravessar uma série de obstáculos para chegar em segurança à sua lagoa. A jornada da rã é dividida em duas partes principais: atravessar uma estrada movimentada e cruzar um rio cheio de perigos.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF89936F),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
