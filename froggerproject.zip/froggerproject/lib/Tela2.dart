import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class Tela2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(child: Text('GamePlay')),
        backgroundColor: const Color.fromARGB(255, 11, 206, 5),
      ),
      body: Center(
        child: Column (
          children: [
          const Text(
            'Em Frogger, você assume o papel de uma pequena rã determinada a atravessar uma série de desafios perigosos para chegar ao seu destino. O objetivo é simples: ajudar a rã a atravessar uma movimentada estrada e um rio cheio de obstáculos, como troncos e crocodilos, para alcançar sua lagoa segura do outro lado da tela.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Color(0xFF89936F),
            ),
          ),

          SizedBox(height: 20),
          Container(
            width: 650,
            height: 650,
            child: Image.network(
              'https://www.krakowpost.com/wp-content/uploads/2018/04/frogger-gif.gif',
              fit: BoxFit.contain,
            ),
          ),
          ],
        ),
      ),
    );
  }
}
