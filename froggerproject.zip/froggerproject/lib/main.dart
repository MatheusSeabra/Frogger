import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:froggerproject/Tela1.dart';
import 'package:froggerproject/Tela2.dart';
import 'package:froggerproject/Tela3.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(child: Text('Frogger')),
        backgroundColor: const Color.fromARGB(255, 11, 206, 5),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              child: Image.asset(
                  'assets/imgs/d6687ro-f06851c0-5d52-45e7-af5f-e407fe27c0f8.png'),
            ),
            ElevatedButton.icon(
              icon: const Icon(Icons.book),
              label: const Text('Historia'),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Tela1()),
                );
              },
            ),
            ElevatedButton.icon(
              icon: const Icon(Icons.games_sharp),
              label: const Text('GamePlay'),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Tela2()),
                );
              },
            ),
            ElevatedButton.icon(
              icon: const Icon(Icons.headset),
              label: const Text('Jogatina'),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Tela3()),
                );
              },
            ),
          ],
        ),
      ),
      backgroundColor: const Color.fromARGB(255, 118, 137, 146),
    );
  }
}
