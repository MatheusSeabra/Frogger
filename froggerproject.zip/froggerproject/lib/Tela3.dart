import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class Tela3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(child: Text('Mecânicas do jogo')),
        backgroundColor: const Color.fromARGB(255, 11, 206, 5),
      ),
      body: Center(
        child: Column(
          children: [
            const Text(
              'Em Frogger, a jogabilidade é bem simples, você apenas precisa atravessar a rua e pega a mosca. Ao decorrer do jogo vai acabando o tempo de jogabilidade, se acabar o tempo, acaba o jogo, logo apos mostra a quantidade de pontos que você fez',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Color(0xFF89936F),
              ),
            ),
            SizedBox(height: 20),
            Container(
              child: Image.asset(
                  'assets/imgs/mecanica.png'),
            ),
          ],
        ),
      ),
    );
  }
}
